#include <iostream>
#include <string>
#include "DiccionarioCuacs.h"
using namespace std;

void DiccionarioCuacs::last(int N) {
    cout << "last " << N << endl;
    cout << "Total: " << 0 << " cuac" << endl; 
}

void DiccionarioCuacs::date(Fecha f1, Fecha f2) {
    cout << "date ";
    f1.mostrar();
    cout << ' ';
    f2.mostrar();
    cout << endl;
    cout << "Total: " << 0 << " cuac" << endl;
}