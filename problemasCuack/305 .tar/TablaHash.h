#ifndef TABLAHASH_H
#define TABLAHASH_H

#include <list>
#include <string>
#include "Cuac.h"
using namespace std;

class Par {
    friend class TablaHash; /*Metodo friend para que tenga acceso*/
    string nombre;
    list<Cuac> l;
};

class ParTag {
    friend class TablaHash; /*Metodo friend para que tenga acceso*/
    string etiqueta;
    list<Cuac*> l;
};

const int M = 1009;

class TablaHash {
private:
    list<Par> T[M];
    list<ParTag> Ttag[M];
    int nElem; /*numeros de usuraios encontrados*/
    int h (string k); /*Metodo privado de Hash*/
public:
    TablaHash ();

    /*Par*/
    Cuac* insertar (Cuac nuevo);
    void consultar (string nombre);
    int numElem (void) { return nElem; }

    /*ParTag*/
    void insertarTag(string etiqueta, Cuac* ref);
    void consultarTag(string etiqueta);
};

#endif