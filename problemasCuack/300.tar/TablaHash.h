#ifndef TABLAHASH_H
#define TABLAHASH_H

#include "Cuac.h" 
#include <list>
#include <string>

//Clase TablaHash
class TablaHash { 
private:
    list<Cuac> *T;
    const int M = 101; 
    int nElem;
    
    int hash(const string &nombre) const; 

public:
    TablaHash ();
    ~TablaHash ();
    Cuac* insertar (Cuac nuevo);
    void consultar (string nombre); 
    int numElem (void) { return nElem; }
};

#endif 