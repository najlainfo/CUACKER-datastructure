#include <iostream>
#include <string>
#include "DiccionarioCuacs.h"
using namespace std; 

//powerpoint
DiccionarioCuacs dic;

void procesar_pcuac(){ //powerpoint
     Cuac nuevo;
    nuevo.leer("pcuac");
    dic.insertar(nuevo);
}
void procesar_mcuac() {
    Cuac nuevo;
    nuevo.leer("mcuac");
    dic.insertar(nuevo);
}
void procesar_last(){
    int n;
    cin >> n;
    dic.last(n);
}

void procesar_follow() { //powerpoint
   string nombre;
    cin >> nombre;
    dic.follow(nombre);
}
void procesar_date() {
   Fecha f1, f2;
    f1.leer();
    f2.leer();
    dic.date(f1, f2);
}

void procesar_exit() { //no hace nada 
    exit(0);
}


void Interprete (string comando) // primera parte hasta el last del power point
{
   if (comando=="pcuac") procesar_pcuac();
   else if (comando=="mcuac") procesar_mcuac();
   else if (comando=="last") procesar_last();
   else if (comando=="follow") procesar_follow();
   else if (comando=="date") procesar_date();
   else if (comando=="exit") procesar_exit();
   
}

int main(void){ //Sacado del powerpoint
    string comando;
   while (cin >> comando)
      Interprete(comando);

}