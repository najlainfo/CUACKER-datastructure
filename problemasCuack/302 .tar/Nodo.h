#ifndef NODO_H
#define NODO_H
#include "Cuac.h"

class Nodo {
    friend class Arbol; /*metodo friends para que arbol pueda acceder*/
   private:
    Cuac *cuac;
    int altura;
    Nodo *izq;
    Nodo *der;

/*Medoto publico de Nodo sacado ambos de powerpoint*/
   public:
    Nodo (Cuac *c) { /*Contructor*/
        cuac = c;
        altura = 0;
        izq = NULL;
        der = NULL;
    }; 
    ~Nodo () { /*destructor*/
        delete izq;
        delete der;
    } 
};

#endif