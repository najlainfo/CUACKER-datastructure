#ifndef CUAC_H
#define CUAC_H

#include "Fecha.h" 
#include <string>

extern const string mensajesPref[30];

// Clase Cuac
class Cuac {
public:
    string usuario;
    Fecha fecha;
    string texto;

    void leer(const string& tipo);
    void mostrar() const;
    bool es_anterior(Cuac &otro);
};

#endif 