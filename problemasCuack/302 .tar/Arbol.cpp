#include "Arbol.h"
#include <iostream>
using namespace std;

/*INICIALIZAR*/
Arbol::Arbol () {
    raiz = NULL;
}

/*ALTURA*/
int Arbol::Altura (Nodo *n) {
    if (n == NULL) return -1;
    return n->altura;
}

/*MAXIMO*/
int Arbol::max (int a, int b) {
    if (a > b) return a;
    else return b;
}

/*ROTACIONES SIMPLES*/
/*->IZQUIERDA*/
void Arbol::RSI (Nodo *&A) {
    Nodo *B = A->izq;
    A->izq = B->der;
    B->der = A;
    A->altura = 1 + max(Altura(A->izq), Altura(A->der));
    B->altura = 1 + max(Altura(B->izq), A->altura);
    A = B;
}

/*->DERECHA*/
void Arbol::RSD (Nodo *&A) {
    Nodo *B = A->der;
    A->der = B->izq;
    B->izq = A;
    A->altura = 1 + max(Altura(A->izq), Altura(A->der));
    B->altura = 1 + max(Altura(B->izq), A->altura);
    A = B;
}

/*ROTACIONES DOBLEMENTE*/
/*->IZQUIERDA*/
void Arbol::RDI (Nodo *&A) {
    RSD(A->izq);
    RSI(A);
}

/*->DERECHA*/
void Arbol::RDD (Nodo *&A) {
    RSI(A->der);
    RSD(A);
}

/*METODOS PRIVADOS*/
void Arbol::insertar (Cuac *ref) {
    insertar(raiz, ref);
}

void Arbol::last(int N) {
    int cont = 0; 
    last(raiz, N, cont);
    cout << "Total: " << cont << " cuac" << endl;
}

void Arbol::date(Fecha f1, Fecha f2) {
    int cont = 0; 
    date(raiz, f1, f2, cont);
    cout << "Total: " << cont << " cuac" << endl;
}

/*METODOS PUBLICOS*/
void Arbol::insertar(Nodo *&n, Cuac *ref) { 
    if (n == NULL) {
        n = new Nodo(ref);
    }
    else {
        if (ref->es_anterior(*(n->cuac))) { 
            insertar(n->izq, ref);
            if (Altura(n->izq) - Altura(n->der) > 1) {
                if (ref->es_anterior(*(n->izq->cuac))) /*Para la izquierda simple*/
                    RSI(n); 
                else /*Sino es doblemente para izquierda*/
                    RDI(n); 
            }
            else {
                n->altura = 1 + max(Altura(n->izq), Altura(n->der)); /*actualizamos altura*/
            }
        } 
        else { 
            insertar(n->der, ref);
            if (Altura(n->der) - Altura(n->izq) > 1) {
                if (!ref->es_anterior(*(n->der->cuac))) /*Para la derecha simple*/
                    RSD(n);
                else /*Sino es doblemente para la derecha*/
                    RDD(n);
            }
            else {
                n->altura = 1 + max(Altura(n->izq), Altura(n->der)); /*actualizamos altura*/
            }
        }
    }

}

void Arbol::last(Nodo *n, int &N, int &cont) {
    if (n == NULL || N == 0) return;
    last(n->izq, N, cont); /*recorrido primero para la izquierda que es el mas reciente*/
    if (N > 0) { 
        cont++;
        cout << cont << ". ";
        n->cuac->escribir();
        N--; 
    } 
    else {
        return; 
    }
    last(n->der, N, cont); /*luego finalmente se recorre el de la derecha que es el mas antiguo*/
}

void Arbol::date(Nodo *n, Fecha f1, Fecha f2, int &cont) {
    if (n == NULL) return; 

    Fecha f = n->cuac->get_fecha();

    if (f.es_menor(f2) || f.es_igual(f2)) { /*si la fecha es menor o igual que f2 vamos al izquierdo*/
        date(n->izq, f1, f2, cont);
    }
    if ((f.es_menor(f2) || f.es_igual(f2)) && (f1.es_menor(f) || f1.es_igual(f))) { /*aqui si la fecha esta entre los dos*/
        cont++;
        cout << cont << ". ";
        n->cuac->escribir();
    }
    if (f1.es_menor(f) || f1.es_igual(f)) { /*si la fecha es menos o igual que f1 al derecho*/
        date(n->der, f1, f2, cont);
    }
}