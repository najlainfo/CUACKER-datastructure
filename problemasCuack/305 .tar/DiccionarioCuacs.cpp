#include "DiccionarioCuacs.h"
#include <iostream>
#include <sstream>
#include <vector>
using namespace std;


/*INICIALIZAR*/
DiccionarioCuacs::DiccionarioCuacs (){
    contador = 0;
}

/*METODOS PUBLICOS*/
/*INSERTAR CUAC*/
void DiccionarioCuacs::insertar(Cuac nuevo){ /*Modificada para el tag*/
    Cuac *ref = tabla.insertar(nuevo);
    arbol.insertar(ref);
    /*Vamos a utilizar los textos para saber si lleva # para contarla como etiqueta*/
    istringstream ss(ref->get_texto());
    string palabra;
    vector<string> etiquetasProcesadas; /*si en una mismo mensaje has dos # que solo lo almacene como uno*/
    while (ss >> palabra) {
        if (palabra.size() > 0 && palabra[0] == '#') {
            bool yaExiste = false;
            for (size_t i = 0; i < etiquetasProcesadas.size(); i++) {
                if (etiquetasProcesadas[i] == palabra) {
                    yaExiste = true;
                    break;
                }
            }
            if (!yaExiste) {
                tabla.insertarTag(palabra, ref);
                etiquetasProcesadas.push_back(palabra);
            }
        }
    }
    contador++;
}

/*LAST*/
void DiccionarioCuacs::last(int N) {
    arbol.last(N);
}

/*FOLLOW*/
void DiccionarioCuacs::follow(string nombre) {
    tabla.consultar(nombre);
}

/*DATE*/
void DiccionarioCuacs::date(Fecha f1, Fecha f2) {
    arbol.date(f1, f2);
}

/*TAG*/
void DiccionarioCuacs::tag(string etiqueta){
    tabla.consultarTag(etiqueta);
}