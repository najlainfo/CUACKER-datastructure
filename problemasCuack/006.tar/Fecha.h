#ifndef FECHA_H
#define FECHA_H

#include <iostream>
#include <string>

using namespace std;

// Clase Fecha
class Fecha {
public:
    int d, m, a, h, min, s;
    void leer();
    void mostrar() const;
    bool es_anterior(const Fecha &f) const;
    bool es_igual(const Fecha &f) const;
};

#endif 