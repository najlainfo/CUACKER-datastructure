#include "DiccionarioCuacs.h"
#include <iostream>
using namespace std;


/*INICIALIZAR*/
DiccionarioCuacs::DiccionarioCuacs (){
    contador = 0;
}

/*METODOS PUBLICOS*/
/*INSERTAR CUAC*/
void DiccionarioCuacs::insertar(Cuac nuevo){
    Cuac *ref = tabla.insertar(nuevo);
    arbol.insertar(ref);
    contador++;   
}

/*LAST*/
void DiccionarioCuacs::last(int N) {
    arbol.last(N);
}

/*FOLLOW*/
void DiccionarioCuacs::follow(string nombre) {
    tabla.consultar(nombre);
}

/*DATE*/
void DiccionarioCuacs::date(Fecha f1, Fecha f2) {
    arbol.date(f1, f2);
}
