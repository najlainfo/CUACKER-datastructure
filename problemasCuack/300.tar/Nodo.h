#ifndef NODO_H
#define NODO_H
#include "Cuac.h"
#include <list>

class Arbol; 

//calse nodo
class Nodo {
friend class Arbol; 

private:
    list<Cuac*> cuacs; 
    Fecha clave_fecha; 
    Nodo *hijo1 = nullptr; // nodo izquierdo(menor)
    Nodo *hijo2 = nullptr; // nodo derecho(mayor)
    int altura = 0; // la altura para un arbol AVL 
public:
    Nodo(Cuac *ref);
    ~Nodo();
};

#endif 