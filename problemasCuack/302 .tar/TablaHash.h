#ifndef TABLAHASH_H
#define TABLAHASH_H

#include <list>
#include <string>
#include "Cuac.h"
using namespace std;

class Par {
    friend class TablaHash; /*Metodo friend para que tenga acceso*/
    string nombre;
    list<Cuac> l;
};

const int M = 1009;

class TablaHash {
private:
    list<Par> T[M];
    int nElem; /*numeros de usuraios encontrados*/
    int h (string k); /*Metodo privado de Hash*/
public:
    TablaHash ();
    Cuac* insertar (Cuac nuevo);
    void consultar (string nombre);
    int numElem (void) { return nElem; }
};

#endif