#include <iostream>
#include <string>
#include <list>
#include "TablaHash.h" 
using namespace std;


int TablaHash::hash(const string &nombre) const {
    unsigned long h = 0;
    for (size_t i = 0; i < nombre.size(); i++) {
        unsigned char c = nombre[i]; 
        h = (h * 131 + c) % M;
    }
    return (int)h;
} 

// Constructor (powerpoint)
TablaHash::TablaHash() {
    T = new list<Cuac>[M];
    nElem = 0;
}

// Powerpoint
TablaHash::~TablaHash() {
    delete[] T; 
}

Cuac* TablaHash::insertar (Cuac nuevo) {
    int nusu = hash(nuevo.usuario);
        list<Cuac> &r = T[nusu];
        list<Cuac>::iterator it;
        it = r.begin();
        while (it != r.end() && it->es_menor(nuevo)) { //utilizado ia para averiguar un error de coherencia que daba wrong answer
            ++it;
        }
        it = r.insert(it, nuevo); 
        nElem++; //Es ahora como el contador_global 
        cout << nElem << " cuac" << endl;
        return &(*it); //Ahora tenemos que devolver un puntero cuac para el árbol
}

void TablaHash::consultar(string nombre) {
    cout << "follow " << nombre << endl;
    int nom = hash(nombre);
    list<Cuac> &r = T[nom];
    int contador = 0;
    list<Cuac>::iterator it;
    
    for (it = r.begin(); it != r.end(); ++it) {
        if (it->usuario == nombre) {
            contador++;
            cout << contador << ". ";
            it->mostrar();
        }
    }
    cout << "Total: " << contador << " cuac" << endl;
}