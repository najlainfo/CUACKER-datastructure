#ifndef ARBOL_H
#define ARBOL_H

#include "Nodo.h"
#include "Fecha.h" 
#include "Cuac.h" 
#include <list>
#include <string>


class DiccionarioCuacs;

class Arbol {
private:
    Nodo *raiz = nullptr; //referencia a nodo
    DiccionarioCuacs *dic_ref = nullptr; //referencia a diccionario 
   
    int altura(Nodo *n) const;
    int balanceo(Nodo *n) const; // altura(hijo2) - altura(hijo1)

    void RSD(Nodo *&nodo);
    void RSI(Nodo *&nodo);
    
    void equilibrar(Nodo *&n);
    void insertar_ordenado_en_lista(list<Cuac*> &lista, Cuac *ref);
    void insertar(Nodo *&n, Cuac *ref);
    void last(Nodo *n, std::list<Cuac*> &res, int &cont, int N);


public:
    Arbol() = default;
    Arbol(DiccionarioCuacs *dic);
    ~Arbol();
    
    void insertar(Cuac *ref);
    void last(int N);
    void date(Fecha f1, Fecha f2);
};

#endif 