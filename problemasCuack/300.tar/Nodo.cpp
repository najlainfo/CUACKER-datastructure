#include <iostream>
#include <string>
#include "Nodo.h"
using namespace std;

Nodo :: Nodo(Cuac *ref) : 
    clave_fecha(ref->fecha) {
    cuacs.push_back(ref);
}
Nodo::~Nodo() {
    delete hijo1; 
    delete hijo2;
}