#ifndef DICCIONARIOCUACS_H
#define DICCIONARIOCUACS_H

#include "Cuac.h" 
#include <list>

// Clase DiccionarioCuacs
class DiccionarioCuacs {
   private:
     list<Cuac> lista;
     int contador;
   public:
     DiccionarioCuacs ();
     void insertar (Cuac nuevo);
     void last (int N);
     void follow (string nombre);
     void date (Fecha f1, Fecha f2);
     int numElem ();
};

#endif 