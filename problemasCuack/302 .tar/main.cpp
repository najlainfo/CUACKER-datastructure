#include "DiccionarioCuacs.h"
#include <iostream>
#include <list>
using namespace std;

DiccionarioCuacs dic;
Cuac actual;

/*INTERPRETE SEGUN EL COMANDO INTRODUCIDO*/
/*->MCUAC*/
void procesar_mcuac() {
    Cuac nuevo;
    nuevo.leer_mcuac(); /*Se lee*/
    dic.insertar(nuevo); /*Se inserta*/
    cout << dic.numElem() << " cuac" << endl; /*Se muestra*/
}

/*->PCUAC*/
void procesar_pcuac() {
    Cuac nuevo;
    nuevo.leer_pcuac();/*Se lee*/
    dic.insertar(nuevo);/*Se inseta*/
    cout << dic.numElem() << " cuac" << endl; /*Se muestra*/
}

/*->LAST*/
void procesar_last() {
    int n;
    cin >> n;
    cout << "last " << n << endl;
    dic.last(n); /*llamada*/
}

/*->FOLLOW*/
void procesar_follow() {
    string nombre;
    cin >> nombre;
    cout << "follow " << nombre << endl;
    dic.follow(nombre); /*llamada*/
}

/*->DATE*/
void procesar_date() {
    Fecha fmin, fmax;
    fmin.leer(); /*se leen las dos fechas*/
    fmax.leer();
    cout << "date ";
    fmin.escribir();/*se escriben*/
    cout << " ";
    fmax.escribir();
    cout << endl;
    dic.date(fmin, fmax);
}

/*->TAG*/
void procesar_tag() {
    string etiqueta;
    cin >> etiqueta;
    cout << "tag " << etiqueta << endl; /*se muestra etiqueta*/
    cout << "1. ";
    actual.escribir(); /*se escribe*/
    cout << "Total: 1 cuac" << endl;
}

void Interprete (string comando){ /*donde se hacen las llamadas a los anteriores funciones*/
    if (comando == "pcuac") procesar_pcuac();
    else if (comando == "mcuac") procesar_mcuac();
    else if (comando == "last") procesar_last();
    else if (comando == "follow") procesar_follow();
    else if (comando == "date") procesar_date();
    else if (comando == "tag") procesar_tag();
}

int main() {
    string comando;

    while (cin >> comando && comando!="exit") {
        Interprete(comando);
    }

    return 0;
}