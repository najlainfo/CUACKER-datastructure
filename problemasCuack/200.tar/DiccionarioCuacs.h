#ifndef DICCIONARIOCUACS_H
#define DICCIONARIOCUACS_H

#include "TablaHash.h" 
#include <list>

// Clase DiccionarioCuacs
class DiccionarioCuacs {
   private:
     TablaHash T;
   public:
     void insertar (Cuac nuevo){T.insertar(nuevo);};
     void last (int N);
     void follow (string nombre){T.consultar(nombre);};
     void date (Fecha f1, Fecha f2);
     int numElem (){return T.numElem();};
};

#endif 