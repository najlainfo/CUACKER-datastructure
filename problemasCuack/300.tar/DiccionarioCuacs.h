#ifndef DICCIONARIOCUACS_H
#define DICCIONARIOCUACS_H
#include "TablaHash.h" 
#include "Arbol.h"
#include <list>

// Clase DiccionarioCuacs
class DiccionarioCuacs {
   private:
     TablaHash T;
     Arbol arbol;
   public:
     DiccionarioCuacs() : arbol(this){} //inicializamos un contructor que hemos utilizado en arbol
     void insertar (Cuac nuevo);
     void follow (string nombre);
     void last (int N); 
     void date (Fecha f1, Fecha f2); 
     int numElem (){return T.numElem();}
};

#endif 