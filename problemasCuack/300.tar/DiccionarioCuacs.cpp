#include <iostream>
#include <string>
#include "DiccionarioCuacs.h"
using namespace std;

void DiccionarioCuacs :: insertar(Cuac nuevo){
    Cuac *ref= T.insertar(nuevo);
    arbol.insertar(ref);
}
void DiccionarioCuacs :: follow(string nombre){
    T.consultar(nombre);
}
void DiccionarioCuacs :: last(int N) {
    arbol.last(N);
}

void DiccionarioCuacs :: date(Fecha f1, Fecha f2) {
    arbol.date(f1, f2);
}