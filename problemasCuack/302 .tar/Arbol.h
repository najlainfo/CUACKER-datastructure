#ifndef ARBOL_H
#define ARBOL_H
#include "Nodo.h"

class Arbol {
  private:
    Nodo *raiz;
    void RSI (Nodo *&A); // simple izquierda
    void RSD (Nodo *&A); // simple derecha
    void RDI (Nodo *&A); // doble izquierda
    void RDD (Nodo *&A); // doble derecha
    
    int max (int a, int b);
    int Altura (Nodo *n);
    void insertar (Nodo *&n, Cuac *ref); //insertar nodo
    void last (Nodo *n, int &N, int &cont); //last con nodo
    void date (Nodo *n, Fecha f1, Fecha f2, int &cont); //daate con nodo

  public:
    Arbol ();
    ~Arbol () {
        delete raiz;
    }
    void insertar (Cuac *ref);
    void last (int N);
    void date (Fecha f1, Fecha f2);
};

#endif