#include <iostream>
#include <string>
#include "Cuac.h"
using namespace std;


const string mensajesPref[30] = {
    "Afirmativo.",
    "Negativo.",
    "Estoy de viaje en el extranjero.",
    "Muchas gracias a todos mis seguidores por vuestro apoyo.",
    "Enhorabuena, campeones!",
    "Ver las novedades en mi pagina web.",
    "Estad atentos a la gran exclusiva del siglo.",
    "La inteligencia me persigue pero yo soy mas rapido.",
    "Si no puedes convencerlos, confundelos.",
    "La politica es el arte de crear problemas.",
    "Donde estan las llaves, matarile, rile, rile...",
    "Si no te gustan mis principios, puedo cambiarlos por otros.",
    "Un dia lei que fumar era malo y deje de fumar.",
    "Yo si se lo que es trabajar duro, de verdad, porque lo he visto por ahi.",
    "Hay que trabajar ocho horas y dormir ocho horas, pero no las mismas.",
    "Mi vida no es tan glamurosa como mi pagina web aparenta.",
    "Todo tiempo pasado fue anterior.",
    "El azucar no engorda... engorda el que se la toma.",
    "Solo los genios somos modestos.",
    "Nadie sabe escribir tambien como yo.",
    "Si le molesta el mas alla, pongase mas aca.",
    "Me gustaria ser valiente. Mi dentista asegura que no lo soy.",
    "Si el dinero pudiera hablar, me diria adios.",
    "Hoy me ha pasado una cosa tan increible que es mentira.",
    "Si no tienes nada que hacer, por favor no lo hagas en clase.",
    "Que nadie se vanaglorie de su justa y digna raza, que pudo ser un melon y salio una calabaza.",
    "Me despido hasta la proxima. Buen viaje!",
    "Cualquiera se puede equivocar, inclusivo yo.",
    "Estoy en Egipto. Nunca habia visto las piramides tan solas.",
    "El que quiera saber mas, que se vaya a Salamanca."
};

void Cuac :: leer(const string& tipo) {
    cin >> usuario;
    fecha.leer();
    cin.ignore(); 

    if (tipo == "pcuac") {
        int num;
        cin >> num;
        cin.ignore(); 
        if (num >= 1 && num <= 30) texto = mensajesPref[num - 1]; // como es [] siempre empieza en 0 entonces si es 30 es posicion 29
        else texto = "Mensaje desconocido"; // por si se sale del numero establecido (un mensjaje de error)
    } else if (tipo == "mcuac") {
        getline(cin, texto);
    }
}

void Cuac :: mostrar() const { // cambiado para que solo se encargue de mostrar el contenido del cuac // idea de IA porque nosotras haciamos actual.mostrar(contador), por lo que habia veces donde la entrada hacia solapaciones y luego imprimia de mas mas luego en el total, por lo que cambiamos a actual.mostrar()
    cout << usuario << ' ';
    fecha.mostrar();
    cout << '\n' << "   " << texto << '\n';
}
bool Cuac :: es_anterior(Cuac &otro) { //nos lo habiamos puesto anteriormente porque no lo vimos 
    if (!fecha.es_igual(otro.fecha)) {
        return otro.fecha.es_anterior(fecha); 
    }
    if (texto != otro.texto) {
        return texto < otro.texto;
    }
    return usuario < otro.usuario;
}