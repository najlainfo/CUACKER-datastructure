#include <iostream>
#include <string>
#include "Fecha.h"
using namespace std;


void Fecha :: leer() {
        char c;
        cin >> d >> c >> m >> c >> a; // para leer fecha del dia -> dia/mes/año
        cin >> h >> c >> min >> c >> s; // para leer el tiempo  -> hora/minuto/segundos
}
void Fecha :: mostrar() const {
        cout << d << '/' << m << '/' << a << ' ';
        if (h < 10) cout << '0';
        cout << h << ':';
        if (min < 10) cout << '0';
        cout << min << ':';
        if (s < 10) cout << '0';
        cout << s;
}
bool Fecha :: es_anterior(const Fecha &f) const { // Idea aportada por la IA, por error para la comparación
        if(a!=f.a) return a<f.a; 
        if(m!=f.m) return m<f.m; 
        if(d!=f.d) return d<f.d;
        if(h!=f.h) return h<f.h; 
        if(min!=f.min) return min<f.min; 
        return s<f.s;
}
bool Fecha :: es_igual(const Fecha &f) const {
        return d==f.d && m==f.m && a==f.a && h==f.h && min==f.min && s==f.s;
}
bool Fecha :: es_posterior_o_igual(const Fecha &f) const {
        return !es_anterior(f);
}
bool Fecha :: es_anterior_o_igual(const Fecha &f) const {
        return es_anterior(f) || es_igual(f);
}