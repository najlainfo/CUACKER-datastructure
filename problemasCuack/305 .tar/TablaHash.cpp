#include "TablaHash.h"
#include <iostream>

/*INICIALIZAR*/
TablaHash::TablaHash (){
    nElem = 0;
}

/*METODO PRIVADO HASH*/
int TablaHash::h (string k) {
    unsigned long res = 0;
    for (unsigned int i = 0; i < k.size(); i++) {
        res = res * 67;
        res = res + k[i];
    }
    return res % M;
}

/*METODOS PUBLICOS*/
/*->INSERTAR*/
Cuac* TablaHash::insertar(Cuac nuevo) {
    string usuario = nuevo.get_usuario();
    int pos = h(usuario); /*ES PARA ENCONTRAR LA POSICION DEL USUARIO EN LA TABLA*/
    list<Par>::iterator it;
    for (it = T[pos].begin(); it != T[pos].end(); it++) {
        if ( (*it).nombre == usuario ) { /*Si el ususario se ha encontrado*/
            list<Cuac>::iterator it2 = (*it).l.begin();
            while (it2 != (*it).l.end() && (*it2).es_anterior(nuevo)) {
                it2++;
            }
            (*it).l.insert(it2,nuevo); 
            it2--;
            return &(*it2);
        }
    }
    /*si el usuario no se encuentra*/
    Par p;
    p.nombre = usuario;
    p.l.push_back(nuevo);
    T[pos].push_back(p); 
    nElem++; 
    list<Par>::iterator itPar = T[pos].end(); 
    itPar--; 
    list<Cuac>::iterator itCuac = (*itPar).l.end(); 
    itCuac--; 
    return &(*itCuac); 
}

/*->CONSULTAR*/
void TablaHash::consultar (string nombre) {
    int pos = h(nombre); /*ES PARA ENCONTRAR LA POSICION DEL USUARIO EN LA TABLA*/
    list<Par>::iterator it;
    for (it = T[pos].begin(); it != T[pos].end(); it++) { 
        if ( (*it).nombre == nombre ) { /*Si el ususario se ha encontrado*/
            list<Cuac>::iterator it2;
            int cont = 0; 
            for (it2 = (*it).l.begin(); it2 != (*it).l.end(); it2++) { 
                cout << (cont + 1) << ". ";
                (*it2).escribir();
                cont++;
            }
            cout << "Total: " << cont << " cuac" << endl;
            return;
        }
    }
    /*Si no se encuentra*/
    cout << "Total: 0 cuac" << endl; 

}
/*METODOS PUBLICOS PARA EL TAG*/
/*->INSERTARTAG*/
void TablaHash::insertarTag(string etiqueta, Cuac* ref) {
    int pos = h(etiqueta); /*PARA ENCONTRAR LA ETIQUETA EN LA TABLA*/
    list<ParTag>::iterator it;
    for (it = Ttag[pos].begin(); it != Ttag[pos].end(); it++) {
        if (it->etiqueta == etiqueta) { /*etiqueta encontrada*/
            list<Cuac*>::iterator it2 = it->l.begin();
            while (it2 != it->l.end() && (*it2)->es_anterior(*ref)) {
                it2++;
            }
            it->l.insert(it2, ref);
            return;
        }
    }
    /*etiqueta no encontrada*/
    ParTag p;
    p.etiqueta = etiqueta;
    p.l.push_back(ref);
    Ttag[pos].push_back(p);
}

/*->CONSULTARTAG*/
void TablaHash::consultarTag(string etiqueta) {
    int pos = h(etiqueta);/*PARA ENCONTRAR LA ETIQUETA EN LA TABLA*/
    list<ParTag>::iterator it;
    for (it = Ttag[pos].begin(); it != Ttag[pos].end(); it++) {
        if (it->etiqueta == etiqueta) { /*Si encuentra la etiqueta*/
            int cont = 0;
            for (Cuac* ptr : it->l) {
                cout << (cont + 1) << ". ";
                ptr->escribir();
                cont++;
            }
            cout << "Total: " << cont << " cuac" << endl;
            return;
        }
    }
    /*Si no la encuentra*/
    cout << "Total: 0 cuac" << endl;
}
/*Es lo mismo que uno normal pero con una palabra enconcreto*/

