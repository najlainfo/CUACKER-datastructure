#include "Arbol.h"
#include <iostream>
using namespace std;

int Arbol :: altura(Nodo *n) const {
    return n == nullptr ? -1 : n->altura; //recorrido para saber la altura del árbol
}
int Arbol :: balanceo(Nodo *n) const { 
    return altura(n->hijo2) - altura(n->hijo1); 
}
void Arbol :: RSD(Nodo *&nodo) {
    Nodo *aux = nodo->hijo1; 
    nodo->hijo1 = aux->hijo2; 
    aux->hijo2 = nodo;       
    nodo->altura = max(altura(nodo->hijo1), altura(nodo->hijo2)) + 1;
    aux->altura = max(altura(aux->hijo1), altura(aux->hijo2)) + 1;
    nodo = aux; 
}
void Arbol :: RSI(Nodo *&nodo) {
    Nodo *aux = nodo->hijo2;
    nodo->hijo2 = aux->hijo1; 
    aux->hijo1 = nodo;
    nodo->altura = max(altura(nodo->hijo1), altura(nodo->hijo2)) + 1;
    aux->altura = max(altura(aux->hijo1), altura(aux->hijo2)) + 1;
    nodo = aux;
}

void Arbol :: equilibrar(Nodo *&n) {
    if (n == nullptr) return; 

    int FE = balanceo(n);

    if (FE > 1) { // Desequilibrio a la derecha (hijo2)
        if (balanceo(n->hijo2) >= 0) { // Caso Derecha-Derecha
            RSI(n);
        } else { // Caso Derecha-Izquierda (RL)
            RSD(n->hijo2); 
            RSI(n);       
        }
    } else if (FE < -1) { // Desequilibrio a la izquierda (hijo1)
        if (balanceo(n->hijo1) <= 0) { 
            RSD(n);
        } else { // Caso Izquierda-Derecha (LR)
            RSI(n->hijo1); 
            RSD(n);        
        }
    }
    // Actualizar la altura 
    n->altura = max(altura(n->hijo1), altura(n->hijo2)) + 1;
}
 //uso de ia: dudas con fechas iguales
void Arbol :: insertar_ordenado_en_lista(list<Cuac*> &lista, Cuac *ref) {
    list<Cuac*>::iterator it = lista.begin();
    while (it != lista.end()) {
        Cuac* actual = *it;
        if (ref->texto < actual->texto) {
            break; 
        } else if (ref->texto == actual->texto) {
            if (ref->usuario < actual->usuario) {
                break; 
            }
        }
        ++it;
    }
    lista.insert(it, ref);
}
//Ahora si insertamos un puntero cuac en el árbol
void Arbol :: insertar(Nodo *&n, Cuac *ref) {
    if (n == nullptr) {
        n = new Nodo(ref);
    } else if (n->clave_fecha.es_igual(ref->fecha)) { // uso de ia: si la fecha es igual vamos al caso del desempate
        insertar_ordenado_en_lista(n->cuacs, ref);
    } else if (ref->fecha.es_anterior(n->clave_fecha)) {//si la fecha es mas antigua la colocamos en la izquierda, es menor
        insertar(n->hijo1, ref);
    } else { // si la fehca es mas reciente se coloca en la derecha, es mayor
        insertar(n->hijo2, ref);
    }
    if (n != nullptr) { // actualizar la altura
        n->altura = max(altura(n->hijo1), altura(n->hijo2)) + 1;
        equilibrar(n);
    }
}
    
void Arbol :: last(Nodo *n, list<Cuac*> &res, int &cont, int N) {
    if (!n || cont >= N) return;

    last(n->hijo2, res, cont, N);

    for (Cuac *c : n->cuacs) {
        if (cont >= N) break;
        res.push_back(c);
        cont++;
    }
    last(n->hijo1, res, cont, N);
}

Arbol::Arbol(DiccionarioCuacs *dic) : dic_ref(dic) {}
Arbol::~Arbol() {
    delete raiz; //destructor 
}
void Arbol::insertar(Cuac *ref) {
    if (ref != nullptr) {
        insertar(raiz, ref);
    }
}

void Arbol::last(int N) {
   cout << "last " << N << endl;
        if (N <= 0) {
            cout << "Total: 0 cuac" << endl;
            return;
        }
        list<Cuac*> res;
        int cont = 0;
        last(raiz, res, cont, N);
        int idx = 0;
        for (Cuac *c : res) {
            cout << ++idx << ". ";
            c->mostrar();
        }
        cout << "Total: " << idx << " cuac" << endl;
}

void Arbol::date(Fecha f1, Fecha f2) {}
