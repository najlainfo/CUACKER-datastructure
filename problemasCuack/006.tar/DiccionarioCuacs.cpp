#include <iostream>
#include <string>
#include <list>
#include "DiccionarioCuacs.h"
using namespace std;

//powerpoint diccionarios
DiccionarioCuacs::DiccionarioCuacs ()
{
   contador= 0;
}
void DiccionarioCuacs::insertar (Cuac nuevo) { //si ponemos el if que esta tambien del powerpoint el ejemplo 2 hace una repeticion al final y no lo pide el enunciado
   list<Cuac>::iterator it= lista.begin();
    while (it != lista.end() && it->es_anterior(nuevo)) //ayuda IA por intentar comparar dos cuacs
        it++;
    lista.insert(it, nuevo);
    contador++;
    cout << contador << " cuac" << endl;
}
void DiccionarioCuacs::last(int N) {
    cout << "last " << N << endl;
    int total = lista.size();
    if (N > total) N = total;  //por si acaso hay mas 
    int i = 1;
    list<Cuac>::iterator it;
    for (it = lista.begin(); it != lista.end() && i <= N; ++it, ++i) {
        cout << i << ". ";
        it->mostrar();
    }
    cout << "Total: " << N << " cuac" << endl;
}

void DiccionarioCuacs::follow(string nombre) {
    cout << "follow " << nombre << endl;
    int i = 0;
    list<Cuac>::iterator it;
    for (it = lista.begin(); it != lista.end(); ++it) { //lo mismo que en last pero con el usuario
        if (it->usuario == nombre) {
            cout << ++i << ". ";
            it->mostrar();
        }
    }
    cout << "Total: " << i << " cuac" << endl;
}
void DiccionarioCuacs::date(Fecha f1, Fecha f2) {
    cout << "date ";
    f1.mostrar();
    cout << ' ';
    f2.mostrar();
    cout << endl;
    int i = 0;
    list<Cuac>::iterator it;
    for ( it = lista.begin(); it != lista.end(); ++it) { // Lo mismo que las otras anteriores pero con las fechas y entre dos 
        if (!it->fecha.es_anterior(f1) && !f2.es_anterior(it->fecha)) {
            cout << ++i << ". ";
            it->mostrar();
        }
    }
    cout << "Total: " << i << " cuac" << endl;
}

